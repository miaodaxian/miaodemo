library(shiny)
library(shinyjs)
library(plotly)
library(lubridate)
library(data.table)
library(dplyr)
library(igraph)
library(amap)

threshold_val_df<-read.csv("/home/k2uxam/TDA/rateInd_v3/threshold_val.csv",sep="|")

shinyServer(function(input, output,session) {
  
  indicator_chart<-reactive({
    
    usty_df<-as.data.frame(fread("/home/k2uxam/Data/usty_rates.csv"))
    
    
    
    target_name<-input$rateSelect
    target_range<-as.numeric(input$target_range)
    indicator<- switch(input$indicator,
                        "MST Length"="MST_length",
                        "Structure Change Ratio"="change_ratio",
                       "TDA Indicator"="tda_ind",
                       "All Above"="combined_ind")  #or survival_ratio,MST_length
    # #threshold_pct<-as.numeric(input$threshold)
    # threshold_pct<-as.numeric(threshold_val_df[threshold_val_df$target_name==target_name & threshold_val_df$target_range == target_range & threshold_val_df$indicator == indicator,"threshold_default"])
    # threshold_pct1<-as.numeric(threshold_val_df[threshold_val_df$target_name==target_name & threshold_val_df$target_range == target_range & threshold_val_df$indicator == "MST_length","threshold_default"])
    # threshold_pct2<-as.numeric(threshold_val_df[threshold_val_df$target_name==target_name & threshold_val_df$target_range == target_range & threshold_val_df$indicator == "change_ratio","threshold_default"])
    # threshold_pct3<-as.numeric(threshold_val_df[threshold_val_df$target_name==target_name & threshold_val_df$target_range == target_range & threshold_val_df$indicator == "tda_ind","threshold_default"])
    
    
    usty_df$DATES<-ymd(usty_df$date)
    
    p<-plot_ly(usty_df, x=~DATES) %>%
       add_trace(y=~get(target_name),name = 'Selected Rate',type="scatter",mode="points") %>%
                layout(title = "Interest Rate Indicator",
                xaxis = list(title = "Date"),
                yaxis = list (title = "Interest Rate"))
    
    #based on inputs, select the read profiles
    mst_ind_df<-read.csv(paste("/home/k2uxam/TDA/rateInd_v3/",target_name,"_",target_range,"_mst.csv",sep=""),sep="|")
    tda_ind_df<-read.csv("/home/k2uxam/TDA/rateInd_v3/dgs_tda_ind.csv",sep="|")
    
    target_df<-usty_df[,c("date",target_name)]
    target_df$target_start<-as.numeric(c(rep(NA,target_range),target_df[,target_name][1:(nrow(target_df)-target_range)]))
    target_df$target_end<-c(target_df[,target_name][(1+target_range):nrow(target_df)],rep(NA,target_range))
    target_df_clean<-na.omit(target_df)
    
    if(indicator != "combined_ind"){
      if(indicator == "MST_length"){
        ind_value<-mst_ind_df$mst_length
        threshold_pct<-as.numeric(input$threshold1)
      }else if(indicator == "change_ratio"){
        ind_value<-mst_ind_df$str_change_ratio_multi
        threshold_pct<-as.numeric(input$threshold2)
      }else if(indicator =="tda_ind"){
        ind_value<-tda_ind_df$dist_diags
        threshold_pct<-as.numeric(input$threshold3)
      }#improve(three combine)
    
      #calculate the condifence level based on threshold,return with p
  
      len_ind<-length(ind_value)
      date_ind<-target_df[1:len_ind,"date"]
      ind_df<-as.data.frame(cbind(date_ind,ind_value))
      colnames(ind_df)<-c("date","ind_value")
    
      final_df<-as.data.frame(merge(ind_df,target_df_clean,by="date",all=FALSE))
      final_df_clean<-na.omit(final_df)
      final_df_clean$delta_change<-abs(final_df_clean$target_end-final_df_clean[,target_name])
      var_val<-var(final_df_clean$delta_change)
      #number 2 can be adjusted
      final_df_clean$label1<- ifelse(final_df_clean$delta_change>2*var_val,1.0,0.0)
      final_df_clean$label2<-ifelse((final_df_clean[,target_name]-final_df_clean$target_start)*(final_df_clean$target_end-final_df_clean[,target_name])<0,1.0,0.0)
      final_df_clean$label<-ifelse(final_df_clean$label1+final_df_clean$label2>=1,1.0,0.0)
      #threshold_pct<-0.10
      threshold_value<-as.numeric(quantile(final_df_clean$ind_value, probs = c(1-threshold_pct)))
      confidence_level<- sum(final_df_clean[final_df_clean$ind_value>=threshold_value,"label"])/nrow(final_df_clean[final_df_clean$ind_value>=threshold_value,])
      #confidence_level

      #color the point of dgs curve when the indicator happens
      above_threshold_df<-final_df_clean[final_df_clean$ind_value>=threshold_value,]
      plot_data<-merge(usty_df,above_threshold_df,by=c(target_name,"date"),all.x=T)
      plot_data$mark<-ifelse(is.na(plot_data$label),"normal","indicator")
    }else{
      ind_list<-list()
      ind_list[[1]]<-mst_ind_df$mst_length
      ind_list[[2]]<-mst_ind_df$str_change_ratio_multi
      ind_list[[3]]<-tda_ind_df$dist_diags
      len_ind<-min(length(ind_list[[1]]),length(ind_list[[2]]),length(ind_list[[3]]))
      
      date_ind<-target_df[1:len_ind,"date"]
      ind_df<-as.data.frame(cbind(date_ind,ind_list[[1]][1:len_ind],ind_list[[2]][1:len_ind],ind_list[[3]][1:len_ind]))
      colnames(ind_df)<-c("date","ind_value1","ind_value2","ind_value3")
      
      final_df<-as.data.frame(merge(ind_df,target_df_clean,by="date",all=FALSE))
      final_df_clean<-na.omit(final_df)
      final_df_clean$delta_change<-abs(final_df_clean$target_end-final_df_clean[,target_name])
      var_val<-var(final_df_clean$delta_change)
      #number 2 can be adjusted
      final_df_clean$label1<- ifelse(final_df_clean$delta_change>2*var_val,1.0,0.0)
      final_df_clean$label2<-ifelse((final_df_clean[,target_name]-final_df_clean$target_start)*(final_df_clean$target_end-final_df_clean[,target_name])<0,1.0,0.0)
      final_df_clean$label<-ifelse(final_df_clean$label1+final_df_clean$label2>=1,1.0,0.0)
      
      threshold_pct1<-as.numeric(input$threshold4)
      threshold_pct2<-as.numeric(input$threshold5)
      threshold_pct3<-as.numeric(input$threshold6)
      threshold_value1<-as.numeric(quantile(final_df_clean$ind_value1, probs = c(1-threshold_pct1)))
      threshold_value2<-as.numeric(quantile(final_df_clean$ind_value2, probs = c(1-threshold_pct2)))
      threshold_value3<-as.numeric(quantile(final_df_clean$ind_value3, probs = c(1-threshold_pct3)))
      
      
      #!!!!start from here
      confidence_level<- sum(final_df_clean[final_df_clean$ind_value1>=threshold_value1 | final_df_clean$ind_value2>=threshold_value2 | final_df_clean$ind_value3>=threshold_value3,"label"])/nrow(final_df_clean[final_df_clean$ind_value1>=threshold_value1 | final_df_clean$ind_value2>=threshold_value2 | final_df_clean$ind_value3>=threshold_value3,])
      above_threshold_df<-final_df_clean[final_df_clean$ind_value1>=threshold_value1 | final_df_clean$ind_value2>=threshold_value2 | final_df_clean$ind_value3>=threshold_value3,]
      plot_data<-merge(usty_df,above_threshold_df,by=c(target_name,"date"),all.x=T)
      plot_data$mark<-ifelse(is.na(plot_data$label),"normal","indicator")
      
    }
    factor(plot_data$mark)
    p<-plot_ly(plot_data, x = ~DATES) %>%
         add_trace(y = ~get(target_name),
            color = ~mark, colors = c("#132B43","#56B1F7"),
            mode = "markers") %>%
      layout(title = "Interest Rate Indicator",
             xaxis = list(title = "Date"),
             yaxis = list (title = "Interest Rate"))
    
    result<-list(p,confidence_level)
    return(result)
 
  })
  
  output$IndicatorPlot<-renderPlotly({
    indicator_chart()[[1]]
  })
  
  output$stats<-renderText({
     
     paste("The confidence level for the selected threshold is: ",sprintf(indicator_chart()[[2]]*100, fmt = '%#.2f'),"%",sep="")
   })
  
  inputchange <- reactive({
    paste(input$rateSelect, input$target_range,input$indicator,sep="")
  })
  observeEvent(inputchange(),{
    target_name<-input$rateSelect
    target_range<-as.numeric(input$target_range)
    indicator<- switch(input$indicator,
                       "MST Length"="MST_length",
                       "Structure Change Ratio"="change_ratio",
                       "TDA Indicator"="tda_ind",
                       "All Above"="combined_ind")  #or survival_ratio,MST_length
    #updateSliderInput(session, "display", value = input$cars)
    mapValue1<-round(as.numeric(threshold_val_df[threshold_val_df$target_name==target_name & threshold_val_df$target_range == target_range & threshold_val_df$indicator == "MST_length","threshold_default"]),2)
    mapValue2<-round(as.numeric(threshold_val_df[threshold_val_df$target_name==target_name & threshold_val_df$target_range == target_range & threshold_val_df$indicator == "change_ratio","threshold_default"]),2)
    mapValue3<-round(as.numeric(threshold_val_df[threshold_val_df$target_name==target_name & threshold_val_df$target_range == target_range & threshold_val_df$indicator == "tda_ind","threshold_default"]),2)
    
    updateSliderInput(session, "threshold1",
                      value = mapValue1,
                      min = 0, max = 1)
    updateSliderInput(session, "threshold2",
                      value = mapValue2,
                      min = 0, max = 1)
    updateSliderInput(session, "threshold3",
                      value = mapValue3,
                      min = 0, max = 1)
    
    updateSliderInput(session, "threshold4",
                      value = mapValue1,
                      min = 0, max = 1)
    updateSliderInput(session, "threshold5",
                      value = mapValue2,
                      min = 0, max = 1)
    updateSliderInput(session, "threshold6",
                      value = mapValue3,
                      min = 0, max = 1)
    # updateSliderInput(session, "distanceRange",
    #                   value = c(min.distance, max.distance),
    #                   min = min.distance, max = max.distance)
  })
  
})

