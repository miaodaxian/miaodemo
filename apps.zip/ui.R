library(shiny)
library(shinythemes)
library(plotly)

threshold_val_df<-read.csv("/home/k2uxam/TDA/rateInd_v3/threshold_val.csv",sep="|")
shinyUI(navbarPage(theme=shinytheme("flatly"),
                   "Interest Rate Reaserch and Analysis",
                   tabPanel("Interest Rate Indicators",
                            sidebarLayout(
                              sidebarPanel(
                                selectInput("rateSelect","Interest Rate Selection",
                                            choices=c("DGS1")),#,"DGS2","DGS3")),#,"DGS5","DGS7","DGS10","DGS20")),
                                hr(),
                                selectInput("target_range","Time Period",
                                            choices = c(120,200)),
                                hr(),
                                
                                selectInput("indicator","Indicators",
                                            choices = c("MST Length","Structure Change Ratio","TDA Indicator","All Above")),
                                hr(),
                                #sliderInput("threshold", "Threshold of the selected indicator",min = 0,max=1,value=0.005),
                                #             #             min = 0, max = 0.2,value = 0.005),
                                conditionalPanel(
                                  "input.indicator == 'MST Length'",
                                  sliderInput("threshold1", "Threshold of MST indicator : ",min = 0,max=1,value=0.05)
                                ),
                                conditionalPanel(
                                  "input.indicator == 'Structure Change Ratio'",
                                  sliderInput("threshold2", "Threshold of MST survival ratio indicator",min = 0,max=1,value=0.05)
                                ),
                                conditionalPanel(
                                  "input.indicator == 'TDA Indicator'",
                                  sliderInput("threshold3", "Threshold of TDA indicator",min = 0,max=1,value=0.05)
                                ),
                                conditionalPanel(
                                  "input.indicator == 'All Above'",
                                  sliderInput("threshold4", "Threshold of MST indicator : ",min = 0,max=1,value=0.05),
                                  sliderInput("threshold5", "Threshold of MST survival ratio indicator",min = 0,max=1,value=0.05),
                                  sliderInput("threshold6", "Threshold of TDA indicator",min = 0,max=1,value=0.05)
                                ),
                                
                                hr(),
                                width=3
                              ),
                              mainPanel(
                                plotlyOutput("IndicatorPlot"),
                                hr(),
                                textOutput("stats")
                                #Accuracy or confidence
                              )
                            ) 
                   )
        ))

